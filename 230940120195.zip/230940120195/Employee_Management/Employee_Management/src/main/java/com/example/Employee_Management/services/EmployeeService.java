package com.example.Employee_Management.services;

import com.example.Employee_Management.dtos.EmployeeDTO;
import com.example.Employee_Management.error_handling.DuplicateEmployeeException;
import com.example.Employee_Management.models.Employee;
import com.example.Employee_Management.models.Gender;
import com.example.Employee_Management.repositories.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class EmployeeService {

    @Autowired
    private EmployeeRepository employeeRepository;

    public EmployeeDTO createEmployee(EmployeeDTO employeeDTO) {
        // Check if email is already associated with an employee
        if (employeeRepository.existsByEmail(employeeDTO.getEmail())) {
            throw new DuplicateEmployeeException();
        }

        // Map DTO to Entity
        Employee employee = new Employee();
        employee.setName(employeeDTO.getName());
        employee.setEmail(employeeDTO.getEmail());
        employee.setJoiningDate(LocalDate.parse(employeeDTO.getJoiningDate()));
        employee.setGender(Gender.valueOf(employeeDTO.getGender().toUpperCase()));

        // Save employee
        Employee savedEmployee = employeeRepository.save(employee);

        // Map Entity back to DTO and return
        return mapEmployeeToDTO(savedEmployee);
    }

    public List<EmployeeDTO> getAllEmployees() {
        List<Employee> employees = employeeRepository.findAll();
        return mapEmployeeListToDTO(employees);
    }

    public EmployeeDTO getEmployeeById(Long id) {
        Employee employee = employeeRepository.findById(id).orElse(null);
        return employee != null ? mapEmployeeToDTO(employee) : null;
    }

    private EmployeeDTO mapEmployeeToDTO(Employee employee) {
        EmployeeDTO employeeDTO = new EmployeeDTO();
        employeeDTO.setId(employee.getId());
        employeeDTO.setName(employee.getName());
        employeeDTO.setEmail(employee.getEmail());
        employeeDTO.setJoiningDate(employee.getJoiningDate().toString());
        employeeDTO.setGender(employee.getGender().toString());
        return employeeDTO;
    }

    private List<EmployeeDTO> mapEmployeeListToDTO(List<Employee> employees) {
        return employees.stream().map(this::mapEmployeeToDTO).collect(Collectors.toList());
    }
}
