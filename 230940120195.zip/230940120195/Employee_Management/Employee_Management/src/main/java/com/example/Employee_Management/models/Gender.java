package com.example.Employee_Management.models;

public enum Gender {
    MALE,
    FEMALE,
    OTHER
}
